 

form = document.getElementById('formchatbox');
form.addEventListener('submit',function(e){
    
    e.preventDefault();
    var data = new FormData(form);

    // Créez une instance de l'objet XMLHttpRequest
    var xhr = new XMLHttpRequest();
    // Configurez une fonction pour gérer la réponse du serveur
    xhr.onreadystatechange = function() {

        if (xhr.readyState == 4 && xhr.status == 200) {
            str = xhr.response;
            document.querySelector("#msg").value=str["msg"];
        }
        else if(xhr.readyState == 4 && xhr.status == 400){
            
            document.querySelector("#handleerrorchatbox").innerHTML=str["msg"];   
        }
        var message = document.getElementById('msg');
        data.append('msg', message.value)
    };
    
    // Ouvrez et envoyez la requête
    xhr.open("POST", '../htbin/chatsend.py', true);
    xhr.responseType = "json";
    xhr.send(data);


});

var xmlhttp = new XMLHttpRequest();

xmlhttp.onreadystatechange = function(){
    if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
        response = xmlhttp.response
        var table = document.querySelector("#dialog");

        for (var i = 0; i < this.response.length; i++){
            var row = `<div class="blockmessage">
            <span class="user">${this.response[i].user}</span>
            <span class= time>${this.response[i].time},</span>
            <span class= date>${this.response[i].date}</span><br>
            <span class="message">${this.response[i].msg}</span><br>
            </div>`
            table.innerHTML += row
        }
            
    }
};

xmlhttp.open("GET", '../htbin/chatget.py', true);
xmlhttp.responseType = "json";
xmlhttp.send()

