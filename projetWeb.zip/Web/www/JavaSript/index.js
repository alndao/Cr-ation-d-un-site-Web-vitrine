const menu = document.querySelector('.burger');
const lien_nav = document.querySelector('.lien_nav');
menu.addEventListener('click', ()=>{
    lien_nav.classList.toggle('navigation');
});
