//Du jquery est utilise ici
form = document.getElementById("connexion");
form.addEventListener("submit", function(e) {
e.preventDefault();
var data = new FormData(form);
var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function(){
    if(xhr.readyState == 4){
        if(xhr.status==200){
           str = xhr.responseText;
           document.querySelector("#result").innerHTML=str;
           document.querySelector(".titreformconnect").style.display="none";
           form.style.display='none';
           document.querySelector("#ramenerformulaire").style.display="block";
        }
        if(xhr.status == 404){
            document.querySelector("#result").innerHTML='File or resource not found';
        }
    }
};

xhr.open('POST','htbin/login.py',true);
xhr.responseType = "text";
xhr.send(data);

});


document.querySelector("#ramenerformulaire").addEventListener("click",function (){
    document.querySelector(".titreformconnect").style.display="inline";
    document.querySelector("#result").style.display="none";
    form.style.display='block';
    document.querySelector("#ramenerformulaire").style.display="none";
});
