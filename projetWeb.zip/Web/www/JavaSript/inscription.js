var estValide = false;

let nom = document.getElementById('lastname');
nom.addEventListener('input', checkLastName);
function checkLastName() {
    if (nom.value == "") {
        nom.style.borderColor = "red";
        document.getElementById('erreur').innerHTML = 'Veiller saisir votre prenom'; 
        estValide = false;
    }
    else {
        nom.style.borderColor = "orangered";
        document.getElementById('erreur').innerHTML = ''; 
        estValide = true;
    }

}
let prenom = document.getElementById('firstname');
prenom.addEventListener('input', checkFirstName);
function checkFirstName() {
    if (prenom.value == "") {
        prenom.style.borderColor = "red";
        document.getElementById('erreur').innerHTML = 'Veiller saisir votre prenom'; 
        estValide = false;
        
    }
    else {
        prenom.style.borderColor = "orangered";
        document.getElementById('erreur').innerHTML = ''; 
        estValide = true;
    }
}



function leapYear(annee){
    return ((annee % 4 == 0 && annee % 100 == 0 ) || annee % 400 == 0);
}

let dateNaissance = document.getElementById('birthday');
dateNaissance.addEventListener('input',checkDate)

function checkDate() {
    console.log(dateNaissance.value);
    let dateNaissance_value = dateNaissance.value;
    let dateListe = dateNaissance_value.toString().split('/',3);
    let jour = dateListe[0];
    let mois = dateListe[1];
    let annee = dateListe[2];
    
    
    var months = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    var days = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
    if (months.indexOf(mois) != -1 && days.indexOf(jour) != -1) {
        if ((mois == '02' && jour == '29' && leapYear(annee) == false) || (mois == '02' && jour == '30') || (mois == '02' && jour == '31') || (mois == '04' && jour == '31') || (mois == '06' && jour == '31') || (mois == '09' && jour == '31') || (mois == '11' && jour == '31'))
        {
            document.getElementById('erreur').innerHTML = 'Date de naissance invalide'; 
            console.log('date invalide');
            dateNaissance.style.borderColor = 'red';
            estValide = false;

        } 
        
        else 
        {
            document.getElementById('erreur').innerHTML = ''; 
            dateNaissance.style.borderColor = 'orangered';
            estValide = true;
        }
    }
    
}

let utilisateur = document.getElementById('username');
utilisateur.addEventListener('input', checkUsername);
function checkUsername() {
    if (utilisateur.value == "") {
        utilisateur.style.borderColor = "red";
        document.getElementById('erreur').innerHTML = 'Veiller saisir votre nom utilisateur'; 
        estValide = false;
    }
      
    else {
        utilisateur.style.borderColor = "orangered";
        document.getElementById('erreur').innerHTML = ''; 
        estValide = true
    }
}

let password = document.getElementById('userpwd');
password.addEventListener('input', checkpwd);
function checkpwd() {
    mod = new RegExp("^(?=.{8,}$)(?=(?:.*?[A-Z]){1})(?=.*?[a-z])(?=(?:.*?[0-9]){1}).*$")

    if (mod.test(password.value) == true) {
        password.style.borderColor = "orangered";
        document.getElementById('erreur').innerHTML = ''; 
        estValide = true;
    }
    else {
        password.style.borderColor = "red"
        document.getElementById('erreur').innerHTML = 'le mot de passe doit contenir au moins <br> un caractere special un majuscule et un chiffre'; 
        estValide = false;
    }
}

let mail = document.getElementById('useremail');
mail.addEventListener('input', checkmail);
function checkmail() {
    mod = new RegExp("^[a-zA-Z0-9_\.\-]+@([a-zA-Z\.]+\.)+[a-zA-Z]{2,6}$")

    if (mod.test(mail.value) == true) {
        mail.style.borderColor = "orangered";
        document.getElementById('erreur').innerHTML = ''; 
        estValide = true;
    }
    else {
        mail.style.borderColor = "red";
        document.getElementById('erreur').innerHTML = 'mail invalide'; 
        estValide = false;
    }
}


    

form = document.getElementById('form');
form.addEventListener('submit',function(e){
    
    if(nom.value == "" || prenom.value == "" || dateNaissance.value == "" || utilisateur.value == "" || password.value == "" || mail.value == ""){
        estValide = false;
    }
    if(estValide == false){
        e.preventDefault();
        
    }
});